public class Carros {
    public static void ligar(){
        System.out.println("O carro foi ligado");
    }
    public static void acelerar(){
        System.out.println("O carro está acelerando");
    }
    public static void frear(){
        System.out.println("O foi freio acionado");
    }
    public static void puxarFreiodeMao(){
        System.out.println("O freio de mão foi puxado");
    }
    public static void trancarPortas(){
        System.out.println("As portas foram trancadas");
    }
    public static void ligarFarol(){
        System.out.println("O farol foi ligado");
    }
    public static void qntdeCombustivel(){
        System.out.println("O carro possui 25L de combustivel no tanque");
    }
    public static void autonomia(){}
}